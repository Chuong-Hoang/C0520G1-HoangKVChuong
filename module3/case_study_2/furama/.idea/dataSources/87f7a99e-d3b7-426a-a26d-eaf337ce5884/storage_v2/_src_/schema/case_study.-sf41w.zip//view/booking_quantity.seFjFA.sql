create definer = root@localhost view booking_quantity as
select `case_study`.`extra_services`.`extra_service_name` AS `extra_service_name`,
       `case_study`.`extra_services`.`price`              AS `price`,
       sum(`case_study`.`detailed_contracts`.`quantity`)  AS `booked_quantity`
from (`case_study`.`detailed_contracts`
         join `case_study`.`extra_services` on ((`case_study`.`detailed_contracts`.`extra_service_id` =
                                                 `case_study`.`extra_services`.`extra_service_id`)))
group by `case_study`.`extra_services`.`extra_service_name`
order by `booked_quantity` desc;

